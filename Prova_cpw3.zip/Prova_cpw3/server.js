
const express = require('express');

const app = express();

app.use(express.json());

let musicas = [
  { id: 1, titulo: "Bohemian Rhapsody", artista: "Queen", nota: 10 },
  { id: 2, titulo: "Imagine", artista: "John Lennon", nota: 9 },
  { id: 3, titulo: "Evidências", artista: "Chitãozinho & Xororó", nota: 8 }
];

let proximoId = 4;

app.get('/musicas', (req, res) => {
  res.json(musicas);
});

app.get('/musicas/:id', (req, res) => {
  const id = Number(req.params.id);

  const musica = musicas.find((m) => m.id === id);

  if (!musica) {
    return res.status(404).json({ erro: "Música não encontrada" });
  }

  res.json(musica);
});

app.get('/top', (req, res) => {
  const top = musicas.filter((m) => m.nota >= 9);

  res.json(top);
});

app.post('/musicas', (req, res) => {
  const { titulo, artista, nota } = req.body;

  if (!titulo || !artista || nota === undefined) {
    return res
      .status(400)
      .json({ erro: "Informe titulo, artista e nota" });
  }

  const novaMusica = {
    id: proximoId,
    titulo: titulo,
    artista: artista,
    nota: nota
  };

  proximoId++;
  musicas.push(novaMusica);

  res.status(201).json(novaMusica);
});

app.delete('/musicas/:id', (req, res) => {
  const id = Number(req.params.id);

  const posicao = musicas.findIndex((m) => m.id === id);

  if (posicao === -1) {
    return res.status(404).json({ erro: "Música não encontrada" });
  }

  musicas.splice(posicao, 1);

  res.status(200).json({ mensagem: "Música removida com sucesso" });
});

app.listen(3001, () => console.log("Servidor rodando na porta 3001"));

